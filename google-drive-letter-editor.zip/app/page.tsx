import type React from "react"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default async function Home() {
  const session = await getServerSession(authOptions)

  if (session) {
    redirect("/dashboard")
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4 bg-gradient-to-b from-slate-50 to-slate-100">
      <div className="max-w-3xl w-full text-center space-y-8">
        <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-slate-900">
          Create and save letters to Google Drive
        </h1>
        <p className="text-xl text-slate-600 max-w-2xl mx-auto">
          A simple way to write, format, and save your letters directly to your Google Drive account.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
          <Button asChild size="lg" className="text-lg px-8">
            <Link href="/api/auth/signin">Get Started</Link>
          </Button>
          <Button asChild variant="outline" size="lg" className="text-lg px-8">
            <Link href="#features">Learn More</Link>
          </Button>
        </div>
      </div>

      <div className="mt-24 max-w-4xl w-full" id="features">
        <h2 className="text-3xl font-bold text-center mb-12 text-slate-900">Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <FeatureCard
            title="Google Authentication"
            description="Securely sign in with your Google account to access your letters."
            icon="LogIn"
          />
          <FeatureCard
            title="Simple Text Editor"
            description="Create and format your letters with our easy-to-use editor."
            icon="Edit3"
          />
          <FeatureCard
            title="Google Drive Integration"
            description="Save your letters directly to your Google Drive account."
            icon="Cloud"
          />
        </div>
      </div>
    </main>
  )
}

function FeatureCard({ title, description, icon }: { title: string; description: string; icon: string }) {
  const icons: Record<string, React.ReactNode> = {
    LogIn: <LogIn className="h-10 w-10 text-slate-700" />,
    Edit3: <Edit3 className="h-10 w-10 text-slate-700" />,
    Cloud: <Cloud className="h-10 w-10 text-slate-700" />,
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200 flex flex-col items-center text-center">
      {icons[icon]}
      <h3 className="text-xl font-semibold mt-4 mb-2 text-slate-800">{title}</h3>
      <p className="text-slate-600">{description}</p>
    </div>
  )
}

import { LogIn, Edit3, Cloud } from "lucide-react"

