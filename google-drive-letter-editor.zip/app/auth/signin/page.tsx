import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ChromeIcon as Google } from "lucide-react"

export default async function SignIn() {
  const session = await getServerSession(authOptions)

  if (session) {
    redirect("/dashboard")
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Sign in to Letter Editor</CardTitle>
          <CardDescription>Connect with your Google account to create and save letters</CardDescription>
        </CardHeader>
        <CardContent>
          <form action="/api/auth/signin/google" method="POST">
            <Button type="submit" className="w-full flex items-center gap-2">
              <Google className="h-5 w-5" />
              <span>Sign in with Google</span>
            </Button>
          </form>
        </CardContent>
        <CardFooter className="text-center text-sm text-muted-foreground">
          By signing in, you agree to our Terms of Service and Privacy Policy
        </CardFooter>
      </Card>
    </div>
  )
}

