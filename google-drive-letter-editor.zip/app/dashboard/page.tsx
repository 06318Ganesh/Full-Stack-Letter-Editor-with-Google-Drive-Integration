import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { DashboardHeader } from "@/components/dashboard-header"
import { LettersList } from "@/components/letters-list"
import { getLetters } from "@/lib/google-drive"

export default async function Dashboard() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/auth/signin")
  }

  const letters = await getLetters(session.accessToken)

  return (
    <div className="min-h-screen bg-slate-50">
      <DashboardHeader user={session.user} />

      <main className="container mx-auto p-4 pt-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-slate-900">Your Letters</h1>
          <Button asChild>
            <Link href="/editor/new">Create New Letter</Link>
          </Button>
        </div>

        <LettersList letters={letters} />
      </main>
    </div>
  )
}

