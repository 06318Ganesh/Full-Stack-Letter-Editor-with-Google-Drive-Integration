import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import { DashboardHeader } from "@/components/dashboard-header"
import { Editor } from "@/components/editor"
import { getLetter } from "@/lib/google-drive"

export default async function EditLetter({
  params,
}: {
  params: { id: string }
}) {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/auth/signin")
  }

  let letterContent = null

  if (params.id !== "new") {
    letterContent = await getLetter(session.accessToken, params.id)

    if (!letterContent) {
      redirect("/dashboard")
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <DashboardHeader user={session.user} />

      <main className="flex-1 container mx-auto p-4 pt-8">
        <Editor initialContent={letterContent} letterId={params.id !== "new" ? params.id : null} />
      </main>
    </div>
  )
}

