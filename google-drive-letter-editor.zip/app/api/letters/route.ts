import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { type NextRequest, NextResponse } from "next/server"
import { createLetter } from "@/lib/google-drive"

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions)

  if (!session || !session.accessToken) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const content = await request.json()
    const result = await createLetter(session.accessToken, content)

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error creating letter:", error)
    return NextResponse.json({ error: "Failed to create letter" }, { status: 500 })
  }
}

