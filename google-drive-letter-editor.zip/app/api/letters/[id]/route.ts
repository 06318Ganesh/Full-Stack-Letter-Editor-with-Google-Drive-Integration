import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { type NextRequest, NextResponse } from "next/server"
import { getLetter, updateLetter, deleteLetter } from "@/lib/google-drive"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)

  if (!session || !session.accessToken) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const letter = await getLetter(session.accessToken, params.id)

    if (!letter) {
      return NextResponse.json({ error: "Letter not found" }, { status: 404 })
    }

    return NextResponse.json(letter)
  } catch (error) {
    console.error("Error fetching letter:", error)
    return NextResponse.json({ error: "Failed to fetch letter" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)

  if (!session || !session.accessToken) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const content = await request.json()
    const result = await updateLetter(session.accessToken, params.id, content)

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error updating letter:", error)
    return NextResponse.json({ error: "Failed to update letter" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)

  if (!session || !session.accessToken) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    await deleteLetter(session.accessToken, params.id)
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting letter:", error)
    return NextResponse.json({ error: "Failed to delete letter" }, { status: 500 })
  }
}

