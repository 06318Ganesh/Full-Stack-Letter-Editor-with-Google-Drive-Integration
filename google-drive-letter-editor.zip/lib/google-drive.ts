import { google } from "googleapis"

// Function to initialize Google Drive API client
function getDriveClient(accessToken: string) {
  const auth = new google.auth.OAuth2()
  auth.setCredentials({ access_token: accessToken })
  return google.drive({ version: "v3", auth })
}

// Get all letters from Google Drive
export async function getLetters(accessToken: string) {
  try {
    const drive = getDriveClient(accessToken)
    const response = await drive.files.list({
      q: "mimeType='application/json' and name contains 'letter_'",
      fields: "files(id, name, modifiedTime)",
      spaces: "drive",
    })

    return response.data.files || []
  } catch (error) {
    console.error("Error fetching letters from Google Drive:", error)
    return []
  }
}

// Get a specific letter from Google Drive
export async function getLetter(accessToken: string, fileId: string) {
  try {
    const drive = getDriveClient(accessToken)
    const response = await drive.files.get({
      fileId,
      alt: "media",
    })

    return response.data
  } catch (error) {
    console.error("Error fetching letter from Google Drive:", error)
    return null
  }
}

// Create a new letter in Google Drive
export async function createLetter(accessToken: string, content: any) {
  try {
    const drive = getDriveClient(accessToken)
    const fileName = `letter_${new Date().toISOString()}`

    const response = await drive.files.create({
      requestBody: {
        name: fileName,
        mimeType: "application/json",
      },
      media: {
        mimeType: "application/json",
        body: JSON.stringify(content),
      },
    })

    return response.data
  } catch (error) {
    console.error("Error creating letter in Google Drive:", error)
    throw error
  }
}

// Update an existing letter in Google Drive
export async function updateLetter(accessToken: string, fileId: string, content: any) {
  try {
    const drive = getDriveClient(accessToken)

    const response = await drive.files.update({
      fileId,
      media: {
        mimeType: "application/json",
        body: JSON.stringify(content),
      },
    })

    return response.data
  } catch (error) {
    console.error("Error updating letter in Google Drive:", error)
    throw error
  }
}

// Delete a letter from Google Drive
export async function deleteLetter(accessToken: string, fileId: string) {
  try {
    const drive = getDriveClient(accessToken)
    await drive.files.delete({
      fileId,
    })
    return true
  } catch (error) {
    console.error("Error deleting letter from Google Drive:", error)
    throw error
  }
}

