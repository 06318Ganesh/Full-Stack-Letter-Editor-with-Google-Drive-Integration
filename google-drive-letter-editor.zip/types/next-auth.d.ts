declare module "next-auth" {
  interface Session {
    accessToken: string
    user: {
      name?: string | null
      email?: string | null
      image?: string | null
    }
  }

  interface JWT {
    accessToken?: string
    refreshToken?: string
    expiresAt?: number
  }
}

