"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Loader2, Save, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useToast } from "@/hooks/use-toast"

interface EditorProps {
  initialContent: any
  letterId: string | null
}

export function Editor({ initialContent, letterId }: EditorProps) {
  const router = useRouter()
  const { toast } = useToast()
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [isSaving, setIsSaving] = useState(false)

  useEffect(() => {
    if (initialContent) {
      setTitle(initialContent.title || "")
      setContent(initialContent.content || "")
    }
  }, [initialContent])

  const handleSave = async () => {
    if (!title.trim()) {
      toast({
        title: "Title required",
        description: "Please provide a title for your letter",
        variant: "destructive",
      })
      return
    }

    setIsSaving(true)

    try {
      const letterData = {
        title,
        content,
        updatedAt: new Date().toISOString(),
      }

      let response

      if (letterId) {
        // Update existing letter
        response = await fetch(`/api/letters/${letterId}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(letterData),
        })
      } else {
        // Create new letter
        response = await fetch("/api/letters", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(letterData),
        })
      }

      if (response.ok) {
        toast({
          title: "Success",
          description: `Letter ${letterId ? "updated" : "created"} successfully`,
        })

        if (!letterId) {
          // If it was a new letter, redirect to dashboard
          router.push("/dashboard")
        }
      } else {
        throw new Error("Failed to save letter")
      }
    } catch (error) {
      console.error("Error saving letter:", error)
      toast({
        title: "Error",
        description: "Failed to save your letter. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Button asChild variant="ghost" size="sm">
          <Link href="/dashboard">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
        </Button>
        <Button onClick={handleSave} disabled={isSaving}>
          {isSaving ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              Save Letter
            </>
          )}
        </Button>
      </div>

      <Card className="p-4 bg-white">
        <div className="mb-4">
          <Input
            type="text"
            placeholder="Letter Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="text-xl font-semibold"
          />
        </div>

        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Write your letter here..."
          className="w-full min-h-[500px] p-4 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </Card>
    </div>
  )
}

