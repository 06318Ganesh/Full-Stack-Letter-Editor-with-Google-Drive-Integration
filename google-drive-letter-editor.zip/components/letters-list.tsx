"use client"

import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Edit, Trash2 } from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"

interface Letter {
  id: string
  name: string
  modifiedTime: string
}

export function LettersList({ letters }: { letters: Letter[] }) {
  const router = useRouter()
  const [isDeleting, setIsDeleting] = useState<string | null>(null)

  const handleDelete = async (id: string) => {
    setIsDeleting(id)
    try {
      const response = await fetch(`/api/letters/${id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        router.refresh()
      } else {
        console.error("Failed to delete letter")
      }
    } catch (error) {
      console.error("Error deleting letter:", error)
    } finally {
      setIsDeleting(null)
    }
  }

  if (letters.length === 0) {
    return (
      <div className="text-center py-12">
        <h3 className="text-xl font-medium text-slate-700 mb-2">No letters found</h3>
        <p className="text-slate-500 mb-6">Create your first letter to get started</p>
        <Button asChild>
          <Link href="/editor/new">Create New Letter</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {letters.map((letter) => (
        <Card key={letter.id} className="overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle className="text-xl truncate">{letter.name}</CardTitle>
          </CardHeader>
          <CardContent className="pb-2">
            <p className="text-sm text-muted-foreground">
              Last modified: {new Date(letter.modifiedTime).toLocaleDateString()}
            </p>
          </CardContent>
          <CardFooter className="flex justify-between pt-2">
            <Button asChild variant="outline" size="sm">
              <Link href={`/editor/${letter.id}`}>
                <Edit className="h-4 w-4 mr-1" />
                Edit
              </Link>
            </Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => handleDelete(letter.id)}
              disabled={isDeleting === letter.id}
            >
              <Trash2 className="h-4 w-4 mr-1" />
              {isDeleting === letter.id ? "Deleting..." : "Delete"}
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

